from flask import Flask, request, render_template, url_for, session, flash, redirect
import mysql.connector
import os

app = Flask(__name__)

@app.route('/login', methods=["POST"])
def login():
	try:
		username = request.form.get('username')
		password = request.form.get('password')
		conn = mysql.connector.connect(user=username, password=password, host='db', port=3306, database='ctf')
		conn.close()
		session['username'] = username
		session['password'] = password
		session['logged_in'] = True
	except Exception as e:
		flash("Incorrect credentials")
	return redirect('/')

@app.route('/', methods=["GET","POST"])
def home():
	if not session.get('logged_in'):
		return render_template("login.html")
	if request.method == "POST":
		query = request.form.get('query')

		try:
			username = session.get('username')
			password = session.get('password')
			conn = mysql.connector.connect(user=username, password=password, host='db', port=3306, database='ctf')
			cursor = conn.cursor()
			cursor.execute(query)
			flag = cursor.fetchone()[0]
			if flag != 'f5e14872aefe':
				return render_template("index.html", error=True)

			conn.close()
			return render_template("flag.html", flag=flag)
		except Exception as e:
			return render_template("index.html", error=True)
	return render_template("index.html")

if __name__ == '__main__':
	app.secret_key = os.urandom(12)
	app.run(host="0.0.0.0", port=5000)